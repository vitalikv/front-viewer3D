# TFlex Viewer

## Установка

```bash
npm install
```

## Команды

### Разработка

```bash
npm run dev
```

Запускает dev-сервер для разработки.

### Сборка

```bash
npm run build
```

Компилирует TypeScript и собирает проект для production.

### Предпросмотр

```bash
npm run preview
```

Запускает предпросмотр собранного проекта.

### Упаковка npm пакет

```bash
npm run pack
```

Собирает проект, создает npm пакет и перемещает его в папку `pack`.

### Форматирование кода

```bash
npm run format
```

Форматирует весь код с помощью Prettier.

```bash
npm run format:check
```

Проверяет форматирование кода без изменений.

### Линтинг

```bash
npm run lint
```

Запускает ESLint с автоматическим исправлением ошибок.

```bash
npm run lint:check
```

Проверяет код на ошибки без автоматического исправления.

### Установка tflex-docs-uiwec-kit
1. Создать файл .npmrc в корне проекта с содержимым файла:
```bash
registry=http://tfs.tsdomain.ru:23333/tfs/DefaultCollection/DOCs.Web/_packaging/DOCsRestApiClient/npm/registry/ 
                        
always-auth=true
```
-------------------------------------------------------
2. Далее каждый разработчик у себя локально создает файл .npmrc в папке рядом с .git-credentials. обычно это папка C:\Users\имя_рабочей_машины. Содержимое файла:
```bash
; begin auth token
//tfs.tsdomain.ru:23333/tfs/DefaultCollection/DOCs.Web/_packaging/DOCsRestApiClient/npm/registry/:username=DefaultCollection
//tfs.tsdomain.ru:23333/tfs/DefaultCollection/DOCs.Web/_packaging/DOCsRestApiClient/npm/registry/:_password=[BASE64_ENCODED_PERSONAL_ACCESS_TOKEN]
//tfs.tsdomain.ru:23333/tfs/DefaultCollection/DOCs.Web/_packaging/DOCsRestApiClient/npm/registry/:email=npm requires email to be set but doesn't use the value
//tfs.tsdomain.ru:23333/tfs/DefaultCollection/DOCs.Web/_packaging/DOCsRestApiClient/npm/:username=DefaultCollection
//tfs.tsdomain.ru:23333/tfs/DefaultCollection/DOCs.Web/_packaging/DOCsRestApiClient/npm/:_password=[BASE64_ENCODED_PERSONAL_ACCESS_TOKEN]
//tfs.tsdomain.ru:23333/tfs/DefaultCollection/DOCs.Web/_packaging/DOCsRestApiClient/npm/:email=npm requires email to be set but doesn't use the value
; end auth token
```

-------------------------------------------------------
3. Редактирование пользовательского .npmrc:
   1. Сгенерировать токен: http://stfs:23333/tfs/DefaultCollection/_usersSettings/tokens с действиями чтения и записи. время жизни выбрать на свое усмотрение(через это время придется обновлять токен по инструкции ниже)
   2. Закодировать токен в base64(из cmd)
        ```bash
        node -e "require('readline') .createInterface({input:process.stdin,output:process.stdout,historySize:0}) .question('PAT> ',p => { b64=Buffer.from(p.trim()).toString('base64');console.log(b64);process.exit(); })"
        ```
   3. Скрипт запросит вставку токена -> вставить токен из 3.1. -> enter -> скопировать строку из cmd
   4. Заменить 
       ```bash
       [BASE64_ENCODED_PERSONAL_ACCESS_TOKEN]
       ``` 
        на закодированный токен из 3.3
   5. //tfs.tsdomain.ru:23333/tfs/DefaultCollection/DOCs.Web/_packaging/DOCsRestApiClient/npm/:email=Тут написать email с которым осуществляется вход в azure(userName@topsystems.ru)

4. Добавить библиотеку в зависимости package.json
```bash
"tflex-docs-uiwec-kit": "^0.16.65",
```

5. Запустите команду
```bash
npm install
```